# Gate 1 analysis

Source: `artifacts/admitted/gate1-m1max-qwen36-q4-v4.json`

Verdict: **NOT PROVEN**

No admitted recoverable pressure gap was detected. Do not build the controller yet.

## Fixed-policy summary

| Arm | Cache MiB | Pressure MiB | n | Decode tok/s | Hit rate | Min free % | Peak compressor growth MiB |
|---|---:|---:|---:|---:|---:|---:|---:|
| cache-slots-16 | 1136 | 0 | 5 | 11.330 | 0.4898 | 51.0 | 714.8 |
| cache-slots-24 | 1704 | 0 | 5 | 11.329 | 0.5715 | 49.0 | 1245.6 |
| cache-slots-32 | 2272 | 0 | 5 | 11.001 | 0.6373 | 47.0 | 1643.9 |
| cache-slots-48 | 3408 | 0 | 5 | 10.495 | 0.7387 | 43.0 | 3158.4 |
| cache-slots-64 | 4544 | 0 | 5 | 10.177 | 0.8117 | 40.0 | 3766.3 |
| cache-slots-96 | 6816 | 0 | 5 | 10.120 | 0.9013 | 32.0 | 5830.0 |

## Candidate pressure gaps

- None admitted.

## Strongest observed tradeoff

- Pair: cache-slots-16 → cache-slots-96
- Aggregate median throughput gap: 10.68%
- Paired median gap: 10.54%
- Paired gaps: 10.72%, 10.84%, 10.54%, 9.45%, 8.94%
- Paired median bootstrap 95% interval: [8.94%, 10.84%]
- Directional support: 5/5
- Hit-rate improvement: 41.15%
- Minimum-free drop: 19.0 percentage points
- Passed 15% gap threshold: False
