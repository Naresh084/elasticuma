# ElasticUMA

ElasticUMA is an evidence-gated research project for **pressure-aware,
bounded-memory language-model inference on Apple Silicon**.

The working hypothesis is that a Mac's fastest safe inference configuration
cannot be selected from model size or expert-cache hit rate alone. Model
weights, routed experts, KV/recurrent state, speculative buffers, the filesystem
cache, Metal, applications, and macOS share one physical unified-memory pool.
A larger cache can improve hit rate while reducing throughput after the system
crosses a compression, reclaim, or swap boundary.

ElasticUMA turns cold routed-expert slots into reload-correct macOS purgeable
Metal resources while keeping the hot working set resident. On the measured
M1 Max/Qwen3.6 workload, the committed implementation is a scoped breakthrough
candidate: it beats both upstream fixed-16 and fixed-96 caches while reducing
fixed-96 peak physical footprint by about one third. A held-out Gemma 4
26B-A4B protocol admits the same mechanism without model-specific tuning, wins
every pair, and reduces fixed-96 footprint by 35.3%. This is **not yet a general
all-Macs/models claim**. Claims are promoted only after their evidence gate
passes.

## Current research gate

**Historical Gate 1: Recoverable pressure gap.** On an M1 Max with a pinned
Qwen3.6-35B-A3B checkpoint and bounded expert streaming, establish whether a
larger expert cache can simultaneously:

1. increase cache hit rate;
2. reduce decode throughput by at least 15%;
3. cross an independently measured macOS pressure boundary; and
4. yield a better configuration that can be selected without loading a second
   model or probing destructively.

This gate determined whether to stop or pivot the original controller paper.
See [docs/CLAIMS.md](docs/CLAIMS.md) and
[docs/METHODOLOGY.md](docs/METHODOLOGY.md).

Gate 1 completed as a negative result: its strongest paired slowdown was 10.54%,
below the frozen 15% threshold. The project pivoted to a different mechanism,
not a lower threshold. Fresh held-out V6/V7 datasets admit a layerwise
OS-managed cache against untouched upstream 16/96-slot baselines. Under 4 GiB
controlled pressure, paired median gains are 7.25% over upstream-16 and 13.67%
over upstream-96; without synthetic pressure, they are 16.91% and 17.59%.
Fixed-96 peak footprint falls 31.6% in both protocols. See
[docs/RESULTS.md](docs/RESULTS.md).

## Safety and storage invariants

- Exactly one model worker may run at a time.
- Model revisions are immutable and recorded by commit SHA.
- One canonical model store is reused across all experiments.
- Downloads are protected by a file lock, projected-size check, total-store
  limit, and 100 GiB default free-disk reserve.
- No experiment may raise macOS wired-memory limits.
- Live pressure generation is opt-in, bounded, monitored, and stopped before a
  critical threshold.
- Raw evidence is immutable; admitted evidence is derived from it.
- Failed approaches are recorded once in [docs/DECISIONS.md](docs/DECISIONS.md)
  rather than retried without a changed hypothesis.

## Quick start

```bash
git clone <repository-url> elasticuma
cd elasticuma
make bootstrap
make check
make doctor
```

Build and verify the immutable external executor:

```bash
make runtime
```

Build the separately pinned ElasticUMA executor from the sibling runtime repo:

```bash
./scripts/bootstrap_candidate_runtime.sh
```

Before the one-time Qwen transfer:

```bash
uv run elasticuma model packed-preflight
```

Only if `allowed` is true:

```bash
uv run elasticuma model install-qwen36
make smoke
```

The repacker streams directly from the immutable Hugging Face revision into one
canonical packed directory; it does not retain a second source snapshot. A
global file lock prevents concurrent transfers, and an interrupted transfer
resumes the same partial artifact. Do **not** also run the generic
`elasticuma model fetch` command for this experiment.

The complete protocol is in
[docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md).

## Repository structure

```text
src/elasticuma/       harness, telemetry, model store, admission, analysis
configs/              immutable experiment specifications
docs/                 claims, prior art, methods, decisions, schemas
paper/                evidence-gated manuscript
artifacts/raw/        immutable run receipts (gitignored)
artifacts/admitted/   validated derived evidence (gitignored)
artifacts/figures/    generated figures (gitignored)
scripts/              reproducible bootstrap and release checks
tests/                parser, safety, scheduling, admission, analysis tests
```

## Publication boundary

An arXiv upload is not peer review. A main-track systems claim requires multiple
Apple generations, multiple MoE architectures, strong resident and bounded
baselines, raw artifacts, exactness/quality checks, energy measurements, and an
independent reproduction. The manuscript contains only evidence-admitted result
numbers and states the remaining cross-chip, energy, and reproduction limits.

## Prior art and attribution

This work is designed around direct prior art including FreeToken, MawForge,
SliceMoE, NPUMoE, FusionML, BaseRT, ZipMoE, MemSpec, EcoSpec, TurboFieldfare,
slipstream, and kernel-managed expert caching. See
[docs/PRIOR_ART.md](docs/PRIOR_ART.md). Existing mechanisms are baselines or
components, not claimed contributions.

The memory and speed planning table—including why Qwen3.8-27B is a dense control
rather than the capacity model—is in [docs/MODEL_MATRIX.md](docs/MODEL_MATRIX.md).

## Research state

- Harness and safety tests: implemented.
- Immutable runtime: pinned and built.
- Primary model: guarded one-copy installation in the canonical cache.
- Gate 1: complete; the strongest paired median slowdown was 10.54%, below the
  preregistered 15% threshold, so the verdict is `NOT PROVEN`.
- Original expert-cache controller: stopped by the evidence gate. Any successor
  direction needs a materially different hypothesis and new held-out protocol.
- Reload-correct purgeable cache: implemented and committed in the separate
  `elasticuma-runtime` source repository at `ec84269`; V6 and V7 pass their
  single-host/model gates against upstream 16/96-slot baselines.
- Generalization: Qwen3.6 and Gemma 4 both pass on the M1 Max. Other Apple
  generations, energy, and independent reproduction remain pending.

See [docs/CLAIMS.md](docs/CLAIMS.md) for the live claim ledger and
[docs/RESULTS.md](docs/RESULTS.md) for admitted measurements. The result-gated
manuscript is [paper/paper.md](paper/paper.md), and the self-contained technical
result report is [reports/gate1/report.html](reports/gate1/report.html).

## License

Apache License 2.0. Model checkpoints retain their own licenses. Third-party
runtime code is not vendored at this stage.
