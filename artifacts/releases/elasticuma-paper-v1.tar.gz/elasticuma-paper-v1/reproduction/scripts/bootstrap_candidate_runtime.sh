#!/bin/sh
set -eu

PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
RUNTIME_ROOT="$PROJECT_ROOT/.runtime/elasticuma"
RUNTIME_REVISION="ec84269d5ce162a0376099d39b30dd19aa99f096"
DEFAULT_LOCAL_SOURCE="$PROJECT_ROOT/../elasticuma-runtime"
RUNTIME_SOURCE=${ELASTICUMA_CANDIDATE_RUNTIME_REPO:-$DEFAULT_LOCAL_SOURCE}

if [ -d "$RUNTIME_ROOT/.git" ]; then
  CURRENT_REVISION=$(git -C "$RUNTIME_ROOT" rev-parse HEAD)
  if [ "$CURRENT_REVISION" != "$RUNTIME_REVISION" ]; then
    echo "refusing to alter candidate runtime at $CURRENT_REVISION" >&2
    echo "expected $RUNTIME_REVISION at $RUNTIME_ROOT" >&2
    exit 2
  fi
elif [ -e "$RUNTIME_ROOT" ]; then
  echo "refusing to overwrite non-Git path: $RUNTIME_ROOT" >&2
  exit 2
else
  if [ "$RUNTIME_SOURCE" = "$DEFAULT_LOCAL_SOURCE" ] && [ ! -d "$RUNTIME_SOURCE/.git" ]; then
    echo "candidate runtime source is not present at $RUNTIME_SOURCE" >&2
    echo "set ELASTICUMA_CANDIDATE_RUNTIME_REPO to the published fork URL" >&2
    exit 2
  fi
  mkdir -p "$PROJECT_ROOT/.runtime"
  git clone --no-checkout "$RUNTIME_SOURCE" "$RUNTIME_ROOT"
  git -C "$RUNTIME_ROOT" checkout --detach "$RUNTIME_REVISION"
fi

git -C "$RUNTIME_ROOT" diff --quiet
git -C "$RUNTIME_ROOT" diff --cached --quiet
swift build -c release --product slipstream --package-path "$RUNTIME_ROOT"
swift build -c release --product slipstream-server --package-path "$RUNTIME_ROOT"

ACTUAL_REVISION=$(git -C "$RUNTIME_ROOT" rev-parse HEAD)
test "$ACTUAL_REVISION" = "$RUNTIME_REVISION"
test -x "$RUNTIME_ROOT/.build/release/slipstream"
test -x "$RUNTIME_ROOT/.build/release/slipstream-server"
echo "candidate runtime ready: $ACTUAL_REVISION"
