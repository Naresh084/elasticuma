# ElasticUMA paper evidence bundle v1

This bundle supports the scoped claim in *ElasticUMA: Reload-Correct OS-Managed
Expert Caching for Apple Silicon*. It includes redacted raw receipts, immutable
admitted JSON, derived analyses, paper figures, reproduction code, pinned model
manifests, and the exact native-runtime patch. It excludes model weights,
runtime build products, secrets, serial numbers, UUIDs, and machine-local paths.

Verify the bundle from this directory with:

```sh
shasum -a 256 -c SHA256SUMS
```

The core evidence contains 75 measured rows: 30 for the rejected Gate-1 cache
sweep and 15 each for Qwen pressure, Qwen no-pressure, and Gemma no-pressure.
The positive claim covers two MoE architectures on one M1 Max. It does not claim
all Apple hardware, energy superiority, or independent reproduction.

To reconstruct the native change, check out slipstream at the upstream commit
in `bundle-metadata.json`, apply `runtime/elasticuma-purgeable.patch`, and build
the release products. The reproduction configs remain safety-gated and must be
given new experiment names rather than appended to canonical raw directories.
